# BigToken - BOT
Fungsi script ini untuk registrasi dan verifikasi otomatis.
Dibuat dengan NodeJS.
# Requirement
- nodejs 8.6.0 +
- internet
- kopi
- cewe
# How to use
```sh
$ git clone https://github.com/wfajriansyahh/bigtoken.git
$ cd bigtoken
$ npm install
$ node index.js
```
# How to use singlefile
```sh
$ git clone https://github.com/wfajriansyahh/bigtoken.git
$ cd bigtoken
$ npm install
$ node singlefile.js REFERALMU LOOP
```